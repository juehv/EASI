/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.juehvtech.easi.actions;

/**
 *
 * @author Jens
 */
public enum Action {
    PING,SHUTDOWN,WOL,RDP;
}
